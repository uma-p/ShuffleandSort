window.onload=function(){
var list = document.getElementById("mainlist");
function shuffleList()
{
 var ul = document.querySelectorAll("ul");
var length = ul[0].querySelectorAll("li").length;

for (var i=0; i<length; i++){
  var rand =  Math.floor(Math.random()*(length));
  ul.forEach(function(ele){
    ele.appendChild(ele.querySelectorAll("li")[rand]);
  });
}
} 
function sortList() { 
   var ul = document.getElementById('mainlist');

  Array.from(ul.getElementsByTagName("li"))
    .sort((a, b) => a.textContent.localeCompare(b.textContent))
    .forEach(li => ul.appendChild(li));
}
document.getElementById("shuffle").onclick = shuffleList;
  
document.getElementById("sort").onclick = sortList;

} 